```text
🌳 SƠ ĐỒ CÂY NHÁNH DỰ ÁN GOMOKU
---------------------------------

Cái này tham khảo thôi nha ae, đặt tên ngắn gọn dễ hiểu là được :v

---------------------------------
[main] (Nhánh ổn định, code nộp bài/demo)
  │
  ├─ [hotfix/tuan-huynh/fix-demo-crash] (Sửa lỗi khẩn cấp phát hiện trên main)
  │
  └─ [develop] (Nhánh phát triển chính, tích hợp tất cả tính năng)
      │
      ├─ [feature/tuan-hoang/auth-login-logic] (Tính năng Đăng nhập - Logic)
      │
      ├─ [feature/tuan-huynh/auth-login-ui] (Tính năng Đăng nhập - UI)
      │
      ├─ [feature/tu/auth-logout] (Tính năng Đăng xuất)
      │
      ├─ [feature/truong/auth-forgot-password] (Tính năng Quên mật khẩu)
      │
      ├─ [feature/tuan-hoang/account-management] (Tính năng Quản lý tài khoản)
      │
      ├─ [feature/tuan-huynh/user-profile] (Tính năng Hồ sơ tài khoản)
      │
      ├─ [feature/tu/main-lobby-screen] (Tính năng Màn hình chính/Sảnh)
      │
      ├─ [feature/truong/matchmaking-logic] (Tính năng Tìm phòng đấu)
      │
      ├─ [feature/tuan-hoang/gameplay-core-logic] (Tính năng Đấu - Logic cốt lõi)
      │
      ├─ [feature/tuan-huynh/gameplay-board-ui] (Tính năng Đấu - UI bàn cờ)
      │
      ├─ [feature/truong/match-history] (Tính năng Lịch sử đấu)
      │
      ├─ [feature/tu/leaderboard-ui] (Tính năng Xếp hạng)
      │
      └─ [bugfix/tuan-hoang/fix-login-null-ref] (Sửa lỗi phát hiện trên develop)
```
